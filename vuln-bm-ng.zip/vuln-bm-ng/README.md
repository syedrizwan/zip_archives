# Vulnerability and Benchmark Ticketing

## Description

The purpose of this automation is to keep track of vulnerabilities discovered and benchmarks of system resources based on the scanning results of Nessus Security Center. This automation create Jira ticketing so that system resource owners are aware and able to address vulnerabilities on system or harden system configuration.

## Components

### CLI Interface
* **main.py**: To execute the automation you use this file with the flag options to enable Security Center fetching, SOS fetching, or Jira ticket creation

```
Vulnerability and Benchmark ticketing process for NextGen.

optional arguments:

  -h, --help            show this help message and exit
  -sc, --sec_center     Fetch vuln and benchmark results from security center.
  -sos, --sos_db        Fetch GENTOR inventory from SOS DB.
  -r, --reports         Create reports from SC and SOS evidence.
  -j, --jira            Execute jira notifier.
  -c, --compress        Compress generated evidence.
```

* **Example:** `# python3 main.py -sc -j`
* **Note:** To execute code for Jira flag alone sc and sos files musts be present in temp directory

### SOS Fetcher
* **inventory_fetcher.py**: Contains code to interact with SOS Inventory. This code will fetch data needed for systems listed within a specific `c_code`. c_code configuration will derive from config.json file
* **Outcome**: Creates "inventory_gentor.json" data file that is used to match with vulnerability and benchmark data for ticket creation

### SC Fetcher
* **sc_fetcher_reports.py**: Contains code to interact with Nessus Security Center. This code will fetch data needed for vulnerability and benchmark ticketing. Code will also leverage configuration from config.json file
* **Outcome**: Will generate data files for agent vulnerabilities, tcp/ip vulnerabilities, and benchmark that get compressed

### Jira Notifier
* **jira_notifier.py**:  Contains code that will leverage data fetched in Nessus Security Center and SOS previously and create new or resolve existing Jira tickets. Code will also summarize results of activity and notify summary and job completion to Slack channel.
* **Outcome**: Summary of results for creating and resolving vulnerabilty and benchmark Jira ticketing.

### Slack Notifier
* **slack_notifier.py**: Contains code for publishing Jira ticketing activity summary on to specific Slack Channel

## Configuration
* config.json: Contains SOS and SC needed data to generate jira ticketing
* env: Contains credentials needed for SC, SOS, and Slack
* constants.py: Contains variable config for logging, data centers within scope, Jira custom fields, Jira filter, and SC filters.

## Requirements
* Jenkins
* Python3
* Python packages in requirements.txt

## Logical View (Diagram)
![Vulnerability and Benchmark Ticketing](./media/Vulnerability and Benchmark Ticketing.jpeg)
