# -*- coding:utf-8; mode:python -*-
import json
from datetime import datetime
from pathlib import Path

from decouple import config
from tenable.sc import TenableSC
from tqdm import tqdm

import vuln_benchmark_ticketing.utils.helper as hlpr
from vuln_benchmark_ticketing.utils.constants import SC_PAGE_SIZE, TZ


class SCFetcher:

    def __init__(self, **params):
        self.__logger, self.__notify = params['logger'], params['slack_notifier']
        self.__config, self.__today = hlpr.load_json('config.json'), datetime.now(TZ).strftime('%Y-%m-%d')
        self.__continue_exec = True
        self.__notify.script_name = 'SecurityCenter Scan Results Fetcher (sc_fetcher.py)'

        # self.__today = '2022-07-25'

        self.__with_compression = params['with_compression']
        self.__file_ext = '.zlib' if self.__with_compression else '.json'

        self.__with_datacenter = params['with_dc']
        self.__dcs_to_report = self.__with_datacenter if self.__with_datacenter else self.__config['main']['dcs_to_report']

        self.__working_folder = Path(self.__config['main']['working_folder'], self.__today, self.__config['security_center']['working_folder'])
        self.__evidence_file = self.__working_folder / f'{self.__config["security_center"]["evidence_file"]}{self.__file_ext}'
        if not self.__working_folder.exists():
            self.__working_folder.mkdir(parents=True)
        else:
            if self.__evidence_file.exists():
                self.__logger.info('SecurityCenter evidence already fetched for today.')
                self.__notify.info('SecurityCenter evidence already fetched for today.')
                self.__continue_exec = False

        if self.__continue_exec:
            self.__security_center = None
            try:
                self.__security_center = TenableSC(config('SC05_URL'), access_key=config('SC05_ACCESS_KEY'), secret_key=config('SC05_SECRET_KEY'))
                # self.__security_center.login(access_key=config('SC05_ACCESS_KEY'), secret_key=config('SC05_SECRET_KEY'))
            except Exception as e:
                self.__notify.error(f'Cannot connect to SecurityCenter. \nException: ```{str(e)}```')
                raise Exception(f'Cannot connect to SecurityCenter. \nException: {str(e)}')

            self.__logger.info('SecurityCenter fetcher initialized.')

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.__logout()

    def fetch(self):
        if not self.__continue_exec:
            return

        self.__logger.info('Fetching security center results.')

        start_time = datetime.now()
        severities = self.__config['security_center'].get('severities', ['1', '2', '3', '4'])
        try:
            for datacenter in self.__dcs_to_report:
                start_time_dc = datetime.now()
                self.__evidence_file = self.__working_folder / f'{self.__config["security_center"]["evidence_file"]}_{datacenter}{self.__file_ext}'
                required_repos = hlpr.get_repos_dc(
                    self.__security_center, self.__config['security_center'].get('environment', 'vpc'), datacenter
                )

                filters = {
                    'severity': ','.join(severities),
                    'repository': required_repos,
                    'last_seen': self.__config['security_center'].get('last_seen', '0:4')
                }
                sc_results = self.__get_inventory(filters)
                end_time_dc = datetime.now()
                self.__logger.info(f'Time taken by SC for {datacenter}: {(end_time_dc - start_time_dc)}')

                try:
                    self.__logger.info(f'Writing {datacenter} SecurityCenter results.')

                    if self.__with_compression:
                        self.__evidence_file.write_bytes(hlpr.compress_text(json.dumps(sc_results)))
                    else:
                        # self.__evidence_file.write_text(json.dumps(sc_results))
                        hlpr.write_json_file(self.__evidence_file, sc_results)

                    end_time_dc = datetime.now()
                    self.__logger.info(f'Time taken to write the SC Evidence - {datacenter}: {(end_time_dc - start_time_dc)}')

                except Exception as e:
                    self.__logger.error(f'Error {datacenter} writing file. Exception: {str(e)}')
                    self.__notify.error(f'Error {datacenter} writing file. Exception: ```{str(e)}```')
                    self.__logout()
                    return

        except Exception as e:
            self.__logger.error(f'Cannot fetch repositories. Exception: {str(e)}')
            self.__notify.error(f'Cannot fetch repositories. Exception: ```{str(e)}```')
            self.__logout()
            return

        end_time = datetime.now()
        self.__logger.info(f'Time taken to execute SC Fetcher: {(end_time - start_time)}')

        self.__logger.info('Results fetched and ready to create reports.')
        self.__notify.success('Results fetched and ready to create reports.')

        self.__logout()

    def __logout(self):
        if self.__security_center is not None:
            self.__security_center.logout()

    def __get_inventory(self, filters):
        """Retrieve inventory from SecurityCenter."""
        # Variable to handle pagination
        offset = 0

        # Make a request (to get total numbers of records)
        total_recs = self.__api_call(filters, offset=offset, page_size=1)['totalRecords']
        pbar = tqdm(total=int(total_recs), ncols=150)

        # To measure the retries of the calls on exception
        retry_count, results = 0, []
        while True:
            # Make the request (to a private function)
            raw_data = self.__api_call(filters, offset=offset, page_size=SC_PAGE_SIZE)

            # If any exception occurred during the call try to make that
            # call again
            if not raw_data:
                # If the exception occurs again and again more than 3 times
                if retry_count <= 3:
                    retry_count += 1
                    continue

                self.__notify.error('Call to SecurityCenter failed more than 3 times. Stopping the execution.')
                raise Exception('Call to SecurityCenter failed more than 3 times. Stopping the execution.')

            # Extract the results from response
            results.extend(raw_data['results'])

            # Increase offset by SC_PAGE_SIZE for next page
            offset += SC_PAGE_SIZE

            # Update progress bar
            pbar.update(int(raw_data['returnedRecords']))

            # If this is the last page then break the loop
            if int(raw_data['returnedRecords']) < SC_PAGE_SIZE:
                break

        pbar.close()

        return results

    def __api_call(self, params, **options):
        try:
            # Make the analysis request using the filters provided
            comp_results = self.__security_center.analysis.vulns(
                ('severity', '=', params['severity']),
                ('repository', '=', params['repository']),
                ('lastSeen', '=', params['last_seen']),
                tool='vulndetails',
                offset=options['offset'],
                limit=options['page_size'],
                json_result=True
            )

            # Return the analysis result
            return comp_results
        except Exception as e:
            self.__logger.error(f'Call to SecurityCenter failed. Exception {str(e)}')
            # Return False if any exception occurred
            # (this will help to execute the same request again)
            return False
