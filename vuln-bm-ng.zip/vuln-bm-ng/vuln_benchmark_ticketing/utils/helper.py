# -*- coding:utf-8; mode:python -*-
import csv
import json
import zlib
from pathlib import Path

from github import Github


def load_json(file):
    try:
        return json.loads(Path(file).read_text())
    except FileNotFoundError:
        return False


def dict_to_csv(csv_file, dict_to_write, write_zero_byte_file=True):
    if len(dict_to_write) == 0:
        if write_zero_byte_file:
            csv_file.write_text('')
            return True
        else:
            return False

    with csv_file.open(mode='w') as f:
        w = csv.writer(f)
        w.writerow(dict_to_write[0].keys())
        for entry in dict_to_write:
            w.writerow(entry.values())

    return True


def csv_to_dict(csv_file):
    reader = csv.DictReader(open(csv_file))
    dict_list = [line for line in reader]

    return dict_list


def decompress_text(compressed_text):
    return zlib.decompress(compressed_text)


def compress_text(text):
    return zlib.compress(text.encode('utf-8'), 9)


def get_repos(security_center, environment, dc_to_report):
    all_repos = security_center.repositories.list(fields=['id', 'name'])
    if environment == 'vpc':
        if dc_to_report == '':
            return [{'id': repo['id']} for repo in all_repos if 'bedrock' not in repo['name'].lower()]
        else:
            return [{'id': repo['id']} for repo in all_repos for dc in dc_to_report if f'_{dc.lower()}' in repo['name'].lower()]
    else:
        return [{'id': repo['id']} for repo in all_repos if 'bedrock' in repo['name'].lower()]


def get_repos_dc(security_center, environment, datacenter):
    all_repos = security_center.repositories.list(fields=['id', 'name'])
    if environment == 'vpc':
        if datacenter == '':
            return [{'id': repo['id']} for repo in all_repos if '_bedrock' not in repo['name'].lower()]
        else:
            return [{'id': repo['id']} for repo in all_repos if f'_{datacenter.lower()}' in repo['name'].lower()]
    else:
        return [{'id': repo['id']} for repo in all_repos if '_bedrock' in repo['name'].lower()]


def get_dc_from_repo(repo_name, environment):
    if environment == 'vpc':
        repo_name = repo_name
        repo_arr = repo_name.split('_')
        # data_center = repo_arr[3].lower() if 'agent' in repo_name.lower() else repo_arr[2].lower()

        if 'agent' in repo_name.lower():
            data_center = repo_arr[3].lower()
        elif '+' in repo_name.lower():
            data_center = repo_arr[1].lower()
        else:
            data_center = repo_arr[2].lower()

        if 'qz2' in repo_name.lower():
            data_center = f'{data_center}qz2'.lower()

        return data_center
    else:
        # ToDo: @William
        #  This is where to extract DC from SC to map with SOS.
        return None


def write_json_file(filepath, content):
    with open(filepath, 'w') as outfile:
        outfile.write(json.dumps(content, indent=1))


def get_team(config, role, mzone, ip, hostname):
    role_name = role.lower()
    if ('qz2' in hostname.lower() or 'pok' in hostname.lower()) and role_name not in ['bmc', 'pdu', 'g5mc']:
        if mzone.lower() in config['mzones']:
            if config['mzones'][mzone][0] != '':
                return config['mzones'][mzone][0]

    if role_name in config['roles']:
        if config['roles'][role_name] != '':
            return config['roles'][role_name]

    return 'Operations' if ip.startswith('10.') else 'Hardware-Sys' if int(ip.split('.')[3]) % 2 == 0 else 'Compute'


def get_assignee(config, mzone, hostname, role):
    role_name = role.lower()
    if ('qz2' in hostname.lower() or 'pok' in hostname.lower()) and role_name not in ['bmc', 'pdu', 'g5mc']:
        if mzone.lower() in config['mzones']:
            return config['mzones'][mzone][1]

    return ''


def get_assignment_config(github_token):
    file_name = 'team_assignee_map_config.json'
    gh = Github(base_url='https://github.ibm.com/api/v3', login_or_token=github_token)
    repo = gh.get_organization('iaas').get_repo('common-service-configuration')

    Path(file_name).write_bytes(repo.get_contents(file_name).decoded_content)

    return file_name
