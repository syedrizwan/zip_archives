# -*- coding:utf-8; mode:python -*-
from datetime import datetime

import requests
from decouple import config
from pytz import timezone


class SlackNotifier:
    def __init__(self, heading):
        """Initialize Slack Client"""
        self.__heading = heading
        self.script_name = ''

        try:
            self.__webhook = config('SLACK_WEBHOOK')
        except KeyError as ke:
            raise KeyError(f'Cannot find Webhook URL. Exception: {ke}')

        if 'https://hooks.slack.com/services/' not in self.__webhook:
            self.__webhook = f'https://hooks.slack.com/services/{self.__webhook}'

        self.__today = datetime.now(timezone('US/Central')).strftime('%m/%d/%Y %I:%M:%S %p')

    @property
    def script_name(self):
        return self.__script_name

    @script_name.setter
    def script_name(self, value):
        self.__script_name = value

    def error(self, message=''):
        self.__send_message('error', self.script_name, message)

    def warning(self, message=''):
        self.__send_message('warning', self.script_name, message)

    def info(self, message=''):
        self.__send_message('info', self.script_name, message)

    def success(self, message=''):
        self.__send_message('success', self.script_name, message)

    def __send_message(self, msg_type, script_name, details):
        if msg_type == 'error':
            color = '#BF271B'
        elif msg_type == 'info':
            color = '#3076B4'
        elif msg_type == 'warning':
            color = '#FAD448'
        elif msg_type == 'success':
            color = '#5ECC3D'
        else:
            color = '#636363'

        slack_data = {
            'attachments': [
                {
                    'color': color,
                    'blocks': [
                        {
                            'type': 'header',
                            'text': {'type': 'plain_text', 'text': self.__heading}
                        },
                        {
                            'type': 'section',
                            'text': {'type': 'mrkdwn', 'text': f'*Script: {script_name}* `{self.__today}`'}
                        },
                        {
                            'type': 'section',
                            'text': {'type': 'mrkdwn', 'text': details}
                        }
                    ]
                }
            ]
        }

        header = {'Content-type': 'application/json', 'Accept': 'application/json'}
        resp = requests.post(self.__webhook, headers=header, json=slack_data)

        if resp.status_code != 200:
            raise RuntimeError(f'Slack message failed to post: {resp.content}')
