# -*- coding:utf-8; mode:python -*-
from pytz import timezone

TZ = timezone('US/Central')

LOGGING_MSG_FORMAT = '%(name)-1s > [%(levelname)s] [%(asctime)s] : %(message)s'
LOGGING_DATE_FORMAT = '%d-%b-%Y %H:%M:%S'

# JIRA
JIRA_VALS = {
    'project_key': 'VULN',
    'vuln_issue_type': 'Vuln-Subtask',
    'benchmark_issue_type': 'Benchmark-Subtask',
    'cf': {
        'ip_address': 'customfield_14109',
        'hostname': 'customfield_11201',
        'port': 'customfield_14110',
        'agent_id': 'customfield_16000',
        'plugin_id': 'customfield_14111',
        'sec_cen_sev': 'customfield_14112',
        'team': 'customfield_10102',
        'model': 'customfield_20514',
        'gentor_role': 'customfield_20801',
        'cluster': 'customfield_20516',
        'application': 'customfield_20515',
        'datacenter': 'customfield_11701',
        'sos_status': 'customfield_21311',
        'os': 'customfield_21312',
        'server_type': 'customfield_21313',
        'mac': 'customfield_21314'
    },
    'agent_component': ['VPCNG'],
    'tcpip_component': ['TCPIP'],
    'benchmark_component': ['CIS Commercial Benchmark', 'VPCNG Agent Benchmark'],
    'transitions': {
        'resolve': '241',
        'back_to_in_progress': '121'
    }
}

JIRA_VALS['agent_vulns_query'] = (
    f'project = {JIRA_VALS["project_key"]} AND '
    f'type = {JIRA_VALS["vuln_issue_type"]} AND '
    f'status != Resolved AND '
    f'(labels != VPC AND labels != CLB) AND '
    f'(component = "{JIRA_VALS["agent_component"][0]}") AND '
    f'(component != "{JIRA_VALS["tcpip_component"][0]}") '
)
JIRA_VALS['tcp_ip_vulns_query'] = (
    f'project = {JIRA_VALS["project_key"]} AND '
    f'type = {JIRA_VALS["vuln_issue_type"]} AND '
    f'status != Resolved AND '
    f'(labels != VPC AND labels != CLB) AND '
    f'(component = "{JIRA_VALS["agent_component"][0]}") AND '
    f'(component = "{JIRA_VALS["tcpip_component"][0]}") '
)
JIRA_VALS['benchmarks_query'] = (
    f'project = {JIRA_VALS["project_key"]} AND '
    f'type = {JIRA_VALS["benchmark_issue_type"]} AND '
    f'status != Resolved AND '
    f'(labels != VPC AND labels != CLB) AND '
    f'(component = "{JIRA_VALS["benchmark_component"][0]}" OR '
    f'component = "{JIRA_VALS["benchmark_component"][1]}") '
)
# SecurityCenter
SC_PAGE_SIZE = 5000

# SOS
INV_TYPES = ['server', 'virtual_ip', 'network_device', 'storage']
INV_PAGE_SIZE = 2000
