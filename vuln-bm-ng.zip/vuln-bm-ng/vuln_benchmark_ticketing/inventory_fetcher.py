# -*- coding:utf-8; mode:python -*-
import json
from datetime import datetime
from pathlib import Path

from decouple import config
from requests import Session
from tqdm import tqdm

import vuln_benchmark_ticketing.utils.helper as hlpr
from vuln_benchmark_ticketing.utils.constants import INV_TYPES, INV_PAGE_SIZE, TZ


class InventoryFetcher:

    def __init__(self, **params):
        self.__logger, self.__notify = params['logger'], params['slack_notifier']
        self.__config, self.__today = hlpr.load_json('config.json'), datetime.now(TZ).strftime('%Y-%m-%d')
        self.__continue_exec = True
        self.__notify.script_name = 'SOS Inventory Fetcher (inventory_fetcher.py)'

        # self.__today = '2022-07-25'

        self.__session = Session()

        self.__working_folder = Path(self.__config['main']['working_folder'], self.__today, self.__config['sos']['working_folder'])
        self.__evidence_file = self.__working_folder / self.__config['sos']['evidence_file']
        if not self.__working_folder.exists():
            self.__working_folder.mkdir(parents=True)
        else:
            if self.__evidence_file.exists():
                self.__logger.info('SOS evidence already fetched for today.')
                self.__notify.info('SOS evidence already fetched for today.')
                self.__continue_exec = False

        if self.__continue_exec:
            self.__session.auth = (config('SOS_EMAIL'), config('SOS_API_KEY'))
            self.__session.headers.update({'Content-Type': 'application/json', 'Accept': 'application/json'})

            self.__logger.info('SOS fetcher initialized.')

    def fetch(self):
        if not self.__continue_exec:
            return

        try:
            start_time = datetime.now()

            inv_config = self.__config['sos']
            self.__logger.info(f'Fetching {inv_config["c_code"].upper()} inventory.')

            inv_params = {'c_code': inv_config['c_code'], 'form': 'ALL'}
            inv_params.update(inv_config.get('filters', {}))

            inventory = self.__make_sos_inv_api_call(**inv_params)

            self.__evidence_file.write_text(json.dumps(inventory, indent=2))

            end_time = datetime.now()
            self.__logger.info(f'{inv_config["c_code"].upper()} inventory from SOS has been fetched successfully.')
            self.__logger.info(f'Time taken to execute SOS Fetcher: {(end_time - start_time)}')
            self.__notify.success(f'{inv_config["c_code"].upper()} inventory from SOS has been fetched successfully.')

        except KeyError as ke:
            self.__logger.error(f'Key not found in config. \nPlease check config.json. {ke}')
            self.__notify.error(f'Key not found in config. \nPlease check config.json. ```{ke}```')

    def __make_sos_inv_api_call(self, **params):
        results, page = [], 1

        try:
            total_recs = self.__make_sos_api_request(params, page_size=1, page=page)['inventory_tracker']['result_size']
            progress_bar = tqdm(total=int(total_recs), ncols=150)

            while True:
                raw_data = self.__make_sos_api_request(params, page_size=INV_PAGE_SIZE, page=page)
                has_contents = False
                for inv_type in INV_TYPES:
                    results_chunk = raw_data['inventory_tracker'].get(inv_type)
                    if results_chunk:
                        has_contents = True
                        for system in results_chunk:
                            system['inventory_type'] = inv_type
                        results.extend(results_chunk)
                progress_bar.update(int(raw_data['inventory_tracker']['page_size']))
                if not has_contents:
                    break
                page += 1

        except ValueError as ve:
            self.__logger.error(ve)
            self.__notify.error(f'```{ve}```')
        except RuntimeError as re:
            self.__logger.error(re)
            self.__notify.error(f'```{re}```')

        return results

    def __make_sos_api_request(self, params, **options):
        params.update({'pageSize': options['page_size'], 'page': options['page']})

        resp = self.__session.get(f'{config("SOS_URL")}/tracker.xsp', params=params)
        resp.raise_for_status()
        try:
            json_resp = json.loads(resp.text)
        except ValueError as e:
            raise ValueError(f'{str(e)}\nResponse: {resp.text}')

        if json_resp.get('error'):
            raise RuntimeError(f'SOS API Error: {json_resp["error"]}')

        return json_resp
