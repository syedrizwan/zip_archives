# -*- coding:utf-8; mode:python -*-
import hashlib
import json
from datetime import datetime
from pathlib import Path

from decouple import config
from jira import JIRA

import vuln_benchmark_ticketing.utils.helper as hlpr
from vuln_benchmark_ticketing.utils.constants import JIRA_VALS, TZ


class JiraNotifier:

    def __init__(self, **params):
        self.__logger, self.__notify = params['logger'], params['slack_notifier']
        self.__config, self.__today = hlpr.load_json('config.json'), datetime.now(TZ).strftime('%Y-%m-%d')
        self.__assignment_config = hlpr.load_json(params['assignment_config_file_name'])
        self.__continue_exec = True
        self.__notify.script_name = 'JIRA Tickets Creator (jira_notifier.py)'

        # self.__today = '2023-07-19'

        self.__with_compression = params['with_compression']
        self.__file_ext = '.zlib' if self.__with_compression else '.json'

        self.__with_datacenter = params['with_dc']
        self.__dcs_to_consider = self.__with_datacenter if self.__with_datacenter else self.__config['main']['dcs_to_report']

        self.__dcs_to_report = ""

        self.__working_folder = Path(self.__config['main']['working_folder'], self.__today, self.__config['reports']['working_folder'])

        self.__agent_vulns_file = Path(self.__working_folder, f'{self.__config["reports"]["agent_vulns_file"]}{self.__file_ext}')
        self.__tcp_ip_vulns_file = Path(self.__working_folder, f'{self.__config["reports"]["tcp_ip_vulns_file"]}{self.__file_ext}')
        self.__benchmarks_file = Path(self.__working_folder, f'{self.__config["reports"]["benchmarks_file"]}{self.__file_ext}')

        if self.__continue_exec:
            try:
                ## SCE-2440
                self.__jira = JIRA(
                    token_auth=config('JIRA_PASSWORD'),
                    options={'verify': False, 'server': config('JIRA_URL')}
                )
            except Exception as ex:
                self.__notify.error(f'Cannot connect to JIRA. Exception: ```{ex}```')
                raise Exception(f'Cannot connect to JIRA. Exception: {ex}')

            self.__logger.info(f'JIRA notifier initialized.')

    def notify(self):
        if not self.__continue_exec:
            return

        jira_manipulation_summary = Path(self.__working_folder, 'jira_summary.txt')

        for datacenter in self.__dcs_to_consider:
            self.__dcs_to_report = set([dc for dc in self.__config['main']['all_dcs'] if datacenter.lower() in dc.lower()])

            self.__agent_vulns_file = Path(self.__working_folder, f'{self.__config["reports"]["agent_vulns_file"]}_{datacenter}{self.__file_ext}')
            self.__tcp_ip_vulns_file = Path(self.__working_folder, f'{self.__config["reports"]["tcp_ip_vulns_file"]}_{datacenter}{self.__file_ext}')
            self.__benchmarks_file = Path(self.__working_folder, f'{self.__config["reports"]["benchmarks_file"]}_{datacenter}{self.__file_ext}')

            if not self.__agent_vulns_file.exists() or not self.__tcp_ip_vulns_file.exists() or not self.__benchmarks_file.exists():
                self.__logger.error('{datacenter}: There are missing or no reports to create tickets. Please execute reports generator first.')
                self.__notify.error('{datacenter}: There are missing or no reports to create tickets. Please execute reports generator first.')
                continue

            # Agent vulns manipulation
            agent_vulns_hash_dict = self.__create_hash_dict(self.__agent_vulns_file, datacenter)
            resolve_result_agent = self.__resolve_tickets(agent_vulns_hash_dict, 'agent', datacenter)
            create_result_agent = self.__create_tickets(agent_vulns_hash_dict, resolve_result_agent, "AGENT", datacenter)

            summary = f'========== {datacenter} AGENT VULNS SUMMARY ==========\n'
            summary += self.__get_summary(resolve_result_agent, create_result_agent)
            self.__logger.info(f'JIRA {datacenter} xtickets created. Summary: \n```{summary}```')

            # TCPIP vulns manipulation
            tcp_ip_vulns_hash_dict = self.__create_hash_dict(self.__tcp_ip_vulns_file, datacenter)
            resolve_result_tcpip = self.__resolve_tickets(tcp_ip_vulns_hash_dict, 'tcpip', datacenter)
            create_result_tcpip = self.__create_tickets(tcp_ip_vulns_hash_dict, resolve_result_tcpip, "TCP-IP", datacenter)

            summary += f'========== {datacenter} TCP IP VULNS SUMMARY ==========\n'
            summary += self.__get_summary(resolve_result_tcpip, create_result_tcpip)
            self.__logger.info(f'JIRA {datacenter}tickets created. Summary: \n```{summary}```')

            # Benchmarks manipulation
            benchmarks_hash_dict = self.__create_hash_dict(self.__benchmarks_file, datacenter)
            resolve_result_benchmark = self.__resolve_tickets(benchmarks_hash_dict, 'benchmark', datacenter)
            create_result_benchmark = self.__create_tickets(benchmarks_hash_dict, resolve_result_benchmark, "BENCHMARK", datacenter)

            summary += f'========== {datacenter} BENCHMARKS SUMMARY ==========\n'
            summary += self.__get_summary(resolve_result_benchmark, create_result_benchmark)
            self.__logger.info(f'JIRA {datacenter} tickets created. Summary: \n```{summary}```')

            jira_manipulation_summary.write_text(summary)

            if (
                    resolve_result_agent['error'] > 0 or
                    resolve_result_tcpip['error'] > 0 or
                    resolve_result_benchmark['error'] > 0 or
                    create_result_agent['error'] > 0 or
                    create_result_tcpip['error'] > 0 or
                    create_result_benchmark['error'] > 0
            ):
                self.__logger.error(f'Errors in {datacenter} JIRA manipulation. Please check the logs, there are some errors reported either creating or resolving tickets. \n```{summary}```')
                self.__notify.error(f'Errors in {datacenter} JIRA manipulation. Please check the logs, there are some errors reported either creating or resolving tickets. \n```{summary}```')
            else:
                self.__logger.info(f'JIRA tickets {datacenter} created. Summary: \n```{summary}```')
                self.__notify.success(f'JIRA tickets {datacenter} created. Summary: \n```{summary}```')

        self.__jira.close()

    def __create_hash_dict(self, compressed_file, datacenter):
        self.__logger.info(f'Hash Dictionary Creation {datacenter} : {compressed_file}')
        hash_dict = {}

        if self.__with_compression:
            self.__logger.info(f'Decompressing {compressed_file}.')
            _dict = json.loads(hlpr.decompress_text(compressed_file.read_bytes()))
        else:
            _dict = json.loads(compressed_file.read_text())

        for entry in _dict:
            if 'tcp_ip' in compressed_file.name:
                port = entry['port'] if entry['port'] != 0 else "None"
                uuid = f'{entry["ip_address"]}|{entry["datacenter"]}|{port}|{entry["plugin_id"]}'
            else:
                uuid = f'{entry["ip_address"]}|{entry["datacenter"]}|{entry["plugin_id"]}'
            hash_dict[uuid.lower()] = entry

        return hash_dict

    def __resolve_tickets(self, hash_dict, vuln_type, datacenter_value):
        open_issues, resolved_issues = {}, {}

        self.__logger.info('Resolving JIRA issues.')
        start_time = datetime.now()

        if vuln_type == 'agent':
            query = JIRA_VALS['agent_vulns_query']
        elif vuln_type == 'tcpip':
            query = JIRA_VALS['tcp_ip_vulns_query']
        else:
            query = JIRA_VALS['benchmarks_query']

        lbls = ' OR labels = '.join(self.__dcs_to_report)
        query = f'{query} AND (labels = {lbls}) ORDER BY created DESC'
        self.__logger.info(f'{datacenter_value} - {vuln_type} - lbls: {lbls}\nQuery:{query}\nDCS to report:{self.__dcs_to_report}')

        success, error, start_at = 0, 0, 0
        while True:
            resolved = 0

            issues = self.__jira.search_issues(query, maxResults=1000, startAt=start_at)

            if len(issues) == 0:
                self.__logger.info(f'{datacenter_value} No issues found to resolve.')
                break
            else:
                self.__logger.info(f'{datacenter_value} Searching... Start index: {start_at}, Issues fetched: {len(issues)} ')

            for issue in issues:
                datacenter = self.__get_dc(issue.fields.labels)
                port = issue.fields.customfield_14110
                ip_address = issue.fields.customfield_14109
                plugin_id = str(issue.fields.summary).split(' ')[0]
                sl_ticket = issue.fields.customfield_14113

                if vuln_type == 'tcpip':
                    uuid = f'{ip_address}|{datacenter}|{port}|{plugin_id}'
                else:
                    uuid = f'{ip_address}|{datacenter}|{plugin_id}'

                if uuid.lower() not in hash_dict:
                    comment = 'Vulnerability not found in Nessus Scans.'
                    try:
                        self.__jira.transition_issue(issue, JIRA_VALS['transitions']['resolve'])

                        resolved += 1
                        self.__logger.info(f'{datacenter_value} - {vuln_type} - Issue resolved. Issue key: {issue.key}. {comment} -- {uuid} -- {sl_ticket}')
                        success += 1
                    except Exception as ex:
                        self.__logger.error(f'{datacenter_value} - {vuln_type} - Error resolving ticket. {ex}')
                        error += 1
                else:
                    open_issues[uuid.lower()] = issue

            start_at += len(issues) - resolved

            if len(issues) < 100:
                break
        end_time = datetime.now()
        self.__logger.info(f'Time taken to Resolve tickets - {vuln_type} : {(end_time - start_time)}')

        return dict(success=success, error=error, open_issues=open_issues)

    def __create_tickets(self, hash_dict, open_issues, vuln_type, datacenter):
        self.__logger.info('Creating {datacenter} JIRA issues.')

        start_time = datetime.now()
        success, error, skipped = 0, 0, 0
        issues_to_create = []
        try:
            for uuid, gap in hash_dict.items():
                if uuid not in open_issues['open_issues']:
                    fields = {
                        'project': {'key': JIRA_VALS['project_key']},
                        'issuetype': {
                            'name': gap['type']
                        },
                        'summary': gap['summary'],
                        'description': gap['description'],
                        'labels': gap['labels'],
                        'priority': {'name': 'Highest' if gap['priority'] == 'Critical' else gap['priority']},
                        JIRA_VALS['cf']['hostname']: gap['hostname'],
                        JIRA_VALS['cf']['ip_address']: gap['ip_address'],
                        JIRA_VALS['cf']['port']: gap['port'],
                        JIRA_VALS['cf']['plugin_id']: [gap['plugin_id']],
                        JIRA_VALS['cf']['agent_id']: gap['agent_id'],
                        JIRA_VALS['cf']['sec_cen_sev']: {'value': gap['sec_cen_sev']},
                        JIRA_VALS['cf']['team']: {'value': gap['team']},
                        JIRA_VALS['cf']['model']: gap['model'],
                        JIRA_VALS['cf']['gentor_role']: gap['role'],
                        JIRA_VALS['cf']['cluster']: gap['cluster'],
                        JIRA_VALS['cf']['application']: gap['application'],
                        JIRA_VALS['cf']['sos_status']: gap['sos_status'],
                        JIRA_VALS['cf']['os']: gap['os'],
                        JIRA_VALS['cf']['server_type']: gap['server_type'],
                        JIRA_VALS['cf']['mac']: gap['mac'],
                        JIRA_VALS['cf']['datacenter']: [{'value': gap['datacenter'].upper()}],
                        'duedate': gap['due_date'],
                        'components': gap['component'],
                        'environment': gap['environment'],
                        'assignee': {'name': gap['assignee']}
                    }
                    issues_to_create.append(fields)
                else:
                    skipped += 1
                    available_issue = open_issues['open_issues'][uuid]

                    fields = self.__update_fields_if_value_change(available_issue, gap)

                    if len(fields) > 0:
                        available_issue.update(fields)

                    self.__logger.info(f'{datacenter} - {vuln_type} - {skipped} - {uuid} - Issue_Key:{available_issue.key} issues already exist.')

                if len(issues_to_create) == 200:
                    _success, _error = self.__create_bulk_issues(issues_to_create, datacenter)
                    success += _success
                    error += _error
                    issues_to_create = []

            if len(issues_to_create) > 0:
                _success, _error = self.__create_bulk_issues(issues_to_create, datacenter)
                success += _success
                error += _error
        except Exception as ex:
            self.__logger.error(f'{datacenter} - Error creating tickets. {ex}')
            error += 1

        end_time = datetime.now()
        self.__logger.info(f'Time taken to Create {datacenter} tickets : {(end_time - start_time)}')

        return dict(success=success, error=error, skipped=skipped)

    def __update_fields_if_value_change(self, available_issue, gap):
        i_hostname = available_issue.fields.customfield_11201
        i_model = available_issue.fields.customfield_20514
        i_gentor_role = available_issue.fields.customfield_20801
        i_cluster = available_issue.fields.customfield_20516
        i_application = available_issue.fields.customfield_20515
        i_datacenter = available_issue.fields.customfield_11701
        i_datacenter = i_datacenter[0].value if i_datacenter is not None else ''
        i_sos_status = available_issue.fields.customfield_21311
        i_os = available_issue.fields.customfield_21312
        i_server_type = available_issue.fields.customfield_21313
        i_mac = available_issue.fields.customfield_21314
        i_desc = available_issue.fields.description
        # i_team = available_issue.fields.customfield_10102

        sos_hostname = gap['hostname']
        sos_model = gap['model']
        sos_gentor_role = gap['role']
        sos_cluster = gap['cluster']
        sos_application = gap['application']
        sos_datacenter = gap['datacenter']
        sos_sos_status = gap['sos_status']
        sos_os = gap['os']
        sos_server_type = gap['server_type']
        sos_mac = gap['mac']
        new_desc = gap['description']
        sos_ip = gap['ip_address']
        should_be_team = hlpr.get_team(self.__assignment_config, sos_gentor_role, sos_cluster, sos_ip, sos_hostname)

        i_desc_hash = i_desc.replace('\n', '').replace('\t', '').replace(' ', '')
        new_desc_hash = new_desc.replace('\n', '').replace('\t', '').replace(' ', '')
        i_desc_hash = hashlib.md5(i_desc_hash.encode('utf-8')).hexdigest()
        new_desc_hash = hashlib.md5(new_desc_hash.encode('utf-8')).hexdigest()

        fields = {}
        if i_hostname != sos_hostname:
            fields[JIRA_VALS['cf']['hostname']] = sos_hostname
            if sos_sos_status.lower() == 'live':
                fields[JIRA_VALS['cf']['team']] = {'value': should_be_team}
                fields['assignee'] = {'name': hlpr.get_assignee(self.__assignment_config, sos_cluster, sos_hostname, sos_gentor_role)}
        if i_model != sos_model:
            fields[JIRA_VALS['cf']['model']] = sos_model
        if i_gentor_role != sos_gentor_role:
            fields[JIRA_VALS['cf']['gentor_role']] = sos_gentor_role
        if i_cluster != sos_cluster:
            fields[JIRA_VALS['cf']['cluster']] = sos_cluster
            if sos_sos_status.lower() == 'live':
                fields[JIRA_VALS['cf']['team']] = {'value': should_be_team}
                fields['assignee'] = {'name': hlpr.get_assignee(self.__assignment_config, sos_cluster, sos_hostname, sos_gentor_role)}
        if i_application != sos_application:
            fields[JIRA_VALS['cf']['application']] = sos_application
        if i_datacenter != sos_datacenter.upper():
            if 'qz2' in sos_hostname:
                sos_datacenter = f'{sos_datacenter}QZ2'
            fields[JIRA_VALS['cf']['datacenter']] = [{'value': sos_datacenter.upper()}]
        if i_sos_status != sos_sos_status:
            fields[JIRA_VALS['cf']['sos_status']] = sos_sos_status
            team = should_be_team if sos_sos_status.lower() == 'live' else 'IPOPs'
            fields[JIRA_VALS['cf']['team']] = {'value': team}
        if i_os != sos_os:
            fields[JIRA_VALS['cf']['os']] = sos_os
        if i_server_type != sos_server_type:
            fields[JIRA_VALS['cf']['server_type']] = sos_server_type
        if i_mac != sos_mac:
            fields[JIRA_VALS['cf']['mac']] = sos_mac
        if i_desc_hash != new_desc_hash:
            fields['description'] = new_desc
        # if 'not found in sos' not in i_sos_status.lower():
        #     if i_team != should_be_team:
        #         if sos_sos_status.lower() == 'live':
        #             fields[JIRA_VALS['cf']['team']] = {'value': should_be_team}
        #         else:
        #             fields[JIRA_VALS['cf']['team']] = {'value': 'IPOPs'}

        return fields

    def __create_bulk_issues(self, issues_to_create, datacenter):
        self.__logger.info(f'Creating {datacenter} {len(issues_to_create)} issues.')
        issue_list = self.__jira.create_issues(issues_to_create, False)
        error, success = 0, 0

        for issue in issue_list:
            ip = issue['input_fields'][JIRA_VALS['cf']['ip_address']]
            pid = issue['input_fields'][JIRA_VALS['cf']['plugin_id']]
            port = issue['input_fields'][JIRA_VALS['cf']['port']]
            lbl = issue['input_fields']['labels']
            dc = self.__get_dc(lbl)

            if issue['status'] == 'Error':
                error += 1
                self.__logger.error(f'{datacenter} - ERROR: {issue["error"]} -- {ip}|{dc}|{port}|{pid}')
            else:
                success += 1
                self.__logger.info(f'{datacenter} Ticket created: Jira_Key:{issue["issue"]} -- {ip}|{dc}|{port}|{pid}')

        self.__logger.info(f'{datacenter} - {success} issues created. Found error in creation of {error} tickets.')
        return success, error

    def __get_dc(self, labels):
        for lbl in labels:
            if lbl.upper() in self.__config['main']['all_dcs']:
                return lbl

        return None

    def __get_summary(self, resolve_result, create_result):
        summary = f'Tickets Resolved: {resolve_result["success"]}\n'
        summary += f'Tickets failed to resolve: {resolve_result["error"]}\n'
        summary += '-----------------------------------------\n'
        summary += f'Tickets created: {create_result["success"]}\n'
        summary += f'Tickets failed to create: {create_result["error"]}\n'
        summary += f'Tickets already present: {create_result["skipped"]}\n\n'
        summary += f'Total Tickets as of today: {create_result["skipped"] + create_result["success"]}\n\n'

        return summary
