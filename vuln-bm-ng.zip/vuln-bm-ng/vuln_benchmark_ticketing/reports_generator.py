# -*- coding:utf-8; mode:python -*-
import json
from datetime import datetime, timedelta
from pathlib import Path
from xml.etree import ElementTree as xml_parser

import vuln_benchmark_ticketing.utils.helper as hlpr
from vuln_benchmark_ticketing.utils.constants import JIRA_VALS, TZ


class ReportsGenerator:

    def __init__(self, **params):
        self.__logger, self.__notify = params['logger'], params['slack_notifier']
        self.__config, self.__today = hlpr.load_json('config.json'), datetime.now(TZ).strftime('%Y-%m-%d')
        self.__assignment_config = hlpr.load_json(params['assignment_config_file_name'])
        self.__continue_exec = True
        self.__notify.script_name = 'Reports Generator (reports_generator.py)'

        # self.__today = '2023-02-20'

        self.__with_datacenter = params['with_dc']
        self.__dcs_to_report = self.__with_datacenter if self.__with_datacenter else self.__config['main']['dcs_to_report']

        self.__with_compression = params['with_compression']
        self.__file_ext = '.zlib' if self.__with_compression else '.json'

        self.__working_folder = Path(self.__config['main']['working_folder'], self.__today, self.__config['reports']['working_folder'])
        self.__sos_evidence = Path(self.__config['main']['working_folder'], self.__today, self.__config['sos']['working_folder'], self.__config['sos']['evidence_file'])
        self.__sc_evidence = Path(
            self.__config['main']['working_folder'],
            self.__today, self.__config['security_center']['working_folder'],
            f'{self.__config["security_center"]["evidence_file"]}{self.__file_ext}'
        )

        self.__agent_vulns_file = Path(self.__working_folder, f'{self.__config["reports"]["agent_vulns_file"]}{self.__file_ext}')
        self.__tcp_ip_vulns_file = Path(self.__working_folder, f'{self.__config["reports"]["tcp_ip_vulns_file"]}{self.__file_ext}')
        self.__benchmarks_file = Path(self.__working_folder, f'{self.__config["reports"]["benchmarks_file"]}{self.__file_ext}')

        if not self.__working_folder.exists():
            self.__working_folder.mkdir(parents=True)
        else:
            if self.__agent_vulns_file.exists() and self.__tcp_ip_vulns_file.exists() and self.__benchmarks_file.exists():
                self.__logger.info('Reports generator ran already and created reports.')
                self.__notify.info('Reports generator ran already and created reports.')
                self.__continue_exec = False
        if not self.__sos_evidence.exists():  # or not self.__sc_evidence.exists():
            self.__logger.error('SOS or security center evidence not present. Please execute the SOS and security center fetchers first.')
            self.__notify.error('SOS or security center evidence not present. Please execute the SOS and security center fetchers first.')
            self.__continue_exec = False

        if self.__continue_exec:
            self.__logger.info('Reports generator initialized.')

    def generate(self):
        if not self.__continue_exec:
            return

        sos_hash_dict = self.__sos_hash_dict()
        for datacenter in self.__dcs_to_report:
            self.__sc_evidence = Path(
                self.__config['main']['working_folder'],
                self.__today, self.__config['security_center']['working_folder'],
                f'{self.__config["security_center"]["evidence_file"]}_{datacenter}{self.__file_ext}'
            )
            self.__agent_vulns_file = Path(self.__working_folder, f'{self.__config["reports"]["agent_vulns_file"]}_{datacenter}{self.__file_ext}')
            self.__tcp_ip_vulns_file = Path(self.__working_folder, f'{self.__config["reports"]["tcp_ip_vulns_file"]}_{datacenter}{self.__file_ext}')
            self.__benchmarks_file = Path(self.__working_folder, f'{self.__config["reports"]["benchmarks_file"]}_{datacenter}{self.__file_ext}')

            sc_results = self.__sc_results()

            self.__logger.info('Comparing and generating reports.')

            start_time = datetime.now()
            agent_vulns, benchmarks, tcp_ip_vulns = [], [], []
            for sc_record in sc_results:
                data_center = hlpr.get_dc_from_repo(sc_record['repository']['name'], self.__config['security_center']['environment'])

                uuid = f'{sc_record["ip"]}|{data_center.upper()}'  ## As sos_hash_dict uuid is based on uppercase sos_hash_dict[f'{ni["ip"]}|{record["datacenter"].upper()}']
                # uuid = f'{sc_record["ip"]}|{data_center}'

                hostname = sos_hash_dict.get(uuid, {'hostname': 'Asset Not Found in SOS'}).get('hostname', 'Hostname Not Found in SOS')
                model = sos_hash_dict.get(uuid, {'model': 'Asset Not Found in SOS'}).get('model', 'Model Not Found in SOS')
                role = sos_hash_dict.get(uuid, {'role': 'Asset Not Found in SOS'}).get('role', 'Role Not Found in SOS')
                mzone = sos_hash_dict.get(uuid, {'mzone': 'Asset Not Found in SOS'}).get('mzone', 'MZone Not Found in SOS')
                cluster = sos_hash_dict.get(uuid, {'cluster': 'Asset Not Found in SOS'}).get('cluster', 'Cluster Not Found in SOS')
                application = sos_hash_dict.get(uuid, {'application': 'Asset Not Found in SOS'}).get('application', 'Application Not Found in SOS')
                datacenter = sos_hash_dict.get(uuid, {'datacenter': 'Asset Not Found in SOS'}).get('datacenter', 'Datacenter Not Found in SOS')
                mac = sos_hash_dict.get(uuid, {'mac': 'Asset Not Found in SOS'}).get('mac', 'Mac Not Found in SOS')
                sos_status = sos_hash_dict.get(uuid, {'sos_status': 'Asset Not Found in SOS'}).get('sos_status', 'Status Not Found in SOS')
                server_type = sos_hash_dict.get(uuid, {'server_type': 'Asset Not Found in SOS'}).get('server_type', 'Server Type Not Found in SOS')
                os = sos_hash_dict.get(uuid, {'os': 'Asset Not Found in SOS'}).get('os', 'OS Not Found in SOS')
                environment = sos_hash_dict.get(uuid, {}).get('environment', '')
                asset_type = sos_hash_dict.get(uuid, {}).get('asset_type', 'Other')

                priority = self.__get_priority(sc_record)
                last_seen = datetime.fromtimestamp(float(sc_record['lastSeen']))
                cves = sc_record['cve'].split(',')

                team_to_assign = hlpr.get_team(self.__assignment_config, role, mzone, sc_record['ip'], hostname) if sos_status.lower() == 'live' else 'IPOPs'

                tmp = dict(
                    summary=f'{sc_record["pluginID"]} - {sc_record["pluginName"]} - VPCNG',
                    priority=priority,  # Based on the Sec Center severity, according to ITSS timeframe (with FBA addendum) and CVSS v3 Score calculation
                    labels=[sc_record['pluginID'], data_center] + cves,
                    ip_address=sc_record['ip'],
                    port=sc_record['port'],
                    plugin_id=sc_record['pluginID'],
                    agent_id=sc_record['uuid'],
                    sec_cen_sev=priority,  # Based on the Sec Center severity, according to ITSS timeframe (with FBA addendum) and CVSS v3 Score calculation
                    # duedate is based on the lastseen date
                    due_date=self.__get_due_date(priority, asset_type, last_seen),  # Based on the Sec Center severity, according to ITSS timeframe (with FBA addendum) and CVSS v3 Score calculation
                    datacenter=data_center,
                    team=team_to_assign,
                    environment=environment,
                    first_seen=datetime.fromtimestamp(float(sc_record['firstSeen'])).strftime('%Y-%m-%d %H:%i:%s'),
                    last_seen=datetime.fromtimestamp(float(sc_record['lastSeen'])).strftime('%Y-%m-%d %H:%i:%s'),
                    assignee=hlpr.get_assignee(self.__assignment_config, mzone, hostname, role),
                    hostname=hostname,
                    role=role,
                    asset_type=asset_type,
                    model=model,
                    cluster=cluster,
                    application=application,
                    mac=mac,
                    sos_status=sos_status,
                    server_type=server_type,
                    os=os,
                    repository=sc_record['repository']['name']
                )
                ref_info = [f'http://cve.mitre.org/cgi-bin/cvename.cgi?name={cve}' for cve in cves]

                if 'cis' in sc_record['repository']['name'].lower():
                    tmp.update(type=JIRA_VALS['benchmark_issue_type'], component=[{'name': component} for component in JIRA_VALS['benchmark_component']])

                    plugin_text = sc_record['pluginText'].replace('>\n', '>').replace('cm:', 'cm-')
                    plugin_text = plugin_text.replace(';&', ';&amp;').replace('&&', '&amp;&amp;')
                    plugin_text = f'<?xml version="1.0"?><data>{plugin_text}</data>'

                    ref = ''
                    try:
                        plugin_text = xml_parser.fromstring(plugin_text)
                        ref = self.__value_or_none(plugin_text, 16).replace('|', ': ').replace(',', '\n')

                    except Exception as e:
                        self.__logger.warning(e)

                    description = (
                        f'*Info:*\n{self.__text_check(sc_record, "synopsis", plugin_text, 13)}\n'
                        f'*Solution:*\n{self.__text_check(sc_record, "solution", plugin_text, 17)}\n'
                        f'*Compliance Policy Value:*\n{{noformat}}{self.__text_check(sc_record, "solution", plugin_text, 10)}{{noformat}}\n'
                        f'*Compliance Actual Value:*\n{{noformat}}{self.__text_check(sc_record, "solution", plugin_text, 7)}{{noformat}}\n'
                        f'*Severity:*\n{sc_record["severity"]["name"]}\n'
                        f'*See Also:*\n{sc_record["seeAlso"]}\n'
                        f'*Plugin Output:*{{noformat}}{self.__text_check(sc_record, "pluginText", plugin_text, 7)}{{noformat}}\n'
                        f'*Risk Information:*\nCVSS v3 Score: {sc_record["cvssV3BaseScore"]}\nCVSS v3 Vector: {sc_record["cvssV3Vector"]}\n'
                        f'*Exploit Information:*\n'
                        f'Exploit Available: {sc_record["exploitAvailable"]}\n'
                        f'Exploit Ease: {sc_record["exploitEase"]}\n'
                        f'Exploit Framework: {sc_record["exploitFrameworks"]}\n'
                        f'*Reference Information:*\nN/A\n'
                        f'*References:*\n'
                        f'{self.__value_or_none(plugin_text, 20)}\n'
                        f'{ref}'
                    )

                    description = description if len(description) < 32300 else (
                        f'{description[:32300]}\n\n--- Snipped long description ---\n'
                        f'View full description at https://www.tenable.com/plugins/index.php?view=single&id={sc_record["pluginID"]}\n'
                    )
                    tmp.update(description=description)

                    benchmarks.append(tmp)
                else:
                    tmp.update(type=JIRA_VALS['vuln_issue_type'])
                    ref_info = '\n'.join(ref_info)
                    cpe = sc_record['cpe'].replace('<br/>', '\n')

                    description = (
                        f'*Synopsis:*\n{sc_record["synopsis"]}\n'
                        f'*Description:*\n{sc_record["description"]}\n'
                        f'*Solution:*\n{sc_record["solution"]}\n'
                        f'*See Also:*\n{sc_record["seeAlso"]}\n'
                        f'*Plugin Output:*\n{{noformat}}{sc_record["pluginText"].replace("<plugin_output>", "").replace("</plugin_output>", "")}{{noformat}}\n'
                        f'*Risk Information:*\nCVSS v3 Score: {sc_record["cvssV3BaseScore"]}\nCVSS v3 Vector: {sc_record["cvssV3Vector"]}\n'
                        f'*Exploit Information:*\n'
                        f'Exploit Available: {sc_record["exploitAvailable"]}\n'
                        f'Exploit Ease: {sc_record["exploitEase"]}\n'
                        f'Exploit Framework: {sc_record["exploitFrameworks"]}\n'
                        f'*Plugin Details:*\n{sc_record["pluginInfo"]}\nFamily: {sc_record["family"]["name"]}\n'
                        f'*Vulnerability Information:*\n{cpe}\n'
                        f'*Reference Information:*\n{ref_info}'
                    )
                    description = description if len(description) < 32300 else (
                        f'{description[:32300]}\n\n--- Snipped long description ---\n'
                        f'View full description at https://www.tenable.com/plugins/index.php?view=single&id={sc_record["pluginID"]}\n'
                    )
                    tmp.update(description=description)

                    if 'vuln' in sc_record['repository']['name'].lower():
                        tmp.update(component=[{'name': component} for component in JIRA_VALS['agent_component']])
                        agent_vulns.append(tmp)
                    else:
                        tmp.update(
                            component=[{'name': component} for component in JIRA_VALS['tcpip_component']] +
                                      [{'name': component} for component in JIRA_VALS['agent_component']]
                        )
                        tcp_ip_vulns.append(tmp)

            try:
                self.__logger.info('Writing reports.')

                if self.__with_compression:
                    self.__agent_vulns_file.write_bytes(hlpr.compress_text(json.dumps(agent_vulns)))
                    self.__tcp_ip_vulns_file.write_bytes(hlpr.compress_text(json.dumps(tcp_ip_vulns)))
                    self.__benchmarks_file.write_bytes(hlpr.compress_text(json.dumps(benchmarks)))
                else:
                    # self.__agent_vulns_file.write_text(json.dumps(agent_vulns))
                    # self.__tcp_ip_vulns_file.write_text(json.dumps(tcp_ip_vulns))
                    # self.__benchmarks_file.write_text(json.dumps(benchmarks))
                    hlpr.write_json_file(self.__agent_vulns_file, agent_vulns)
                    hlpr.write_json_file(self.__tcp_ip_vulns_file, tcp_ip_vulns)
                    hlpr.write_json_file(self.__benchmarks_file, benchmarks)


            except Exception as e:
                self.__logger.error(f'Error writing file. \nException: {str(e)}')
                self.__notify.error(f'Error writing file. \nException: ```{str(e)}```')
                return
        end_time = datetime.now()
        self.__logger.info(f'Time taken to execute Report Generator: {(end_time - start_time)}')
        self.__logger.info('Reports are ready to create tickets.')
        self.__notify.success('Reports are ready to create tickets.')

    def __get_priority(self, sc_record):
        cvss_v3_score = float(sc_record['cvssV3BaseScore']) if sc_record.get('cvssV3BaseScore') else 0.0

        if 0.1 <= cvss_v3_score <= 3.9:
            return 'Low'
        elif 4.0 <= cvss_v3_score <= 6.9:
            return 'Medium'
        elif 7.0 <= cvss_v3_score <= 8.9:
            return 'High'
        elif 9.0 <= cvss_v3_score <= 10.0:
            return 'Critical'
        else:
            # get priority from sc severity if no cvss score
            return sc_record['severity']['name']

    # SCE-1619 #SCE-2163
    def __get_due_date(self, priority, asset_type, asset_seen):
        if priority == 'Low':
            days_to_add = 180 if asset_type != 'Internet' else 30
        elif priority == 'Medium':
            days_to_add = 60 if asset_type != 'Internet' else 30
        elif priority == 'High':
            days_to_add = 30 if asset_type != 'Internet' else 30
        else:
            days_to_add = 30 if asset_type != 'Internet' else 30

        return (asset_seen + timedelta(days=days_to_add)).strftime('%Y-%m-%d')

    def __value_or_none(self, arr, index):
        try:
            return arr[index].text
        except IndexError:
            return 'N/A'
        except AttributeError:
            return arr[index]

    def __text_check(self, sc_record, text_index, plugin_text, index):
        text_value = self.__value_or_none(plugin_text, index)
        if text_value == 'N/A':
            text_value = sc_record[text_index]
        else:
            text_value = self.__value_or_none(plugin_text, index)

        return text_value

    def __sos_hash_dict(self):
        self.__logger.info('Reading SOS inventory.')
        sos_inventory = json.loads(self.__sos_evidence.read_text())

        sos_hash_dict = {}
        for record in sos_inventory:
            for ni in record['network_interface']:
                if 'qz2' in record['hostname'].lower():
                    uuid = f'{ni["ip"]}|{record["datacenter"]}qz2'.upper()
                else:
                    uuid = f'{ni["ip"]}|{record["datacenter"]}'.upper()

                manufacturer = record.get('hardware', {}).get('manufacturer', '')
                model = record.get('hardware', {}).get('model', '')
                sos_status = record.get('status', '')
                server_type = record.get('type', '')
                os_title = record.get('os', {}).get('title', '')
                os_version = record.get('os', {}).get('version', '')
                os_architecture = record.get('os', {}).get('architecture', '')
                sos_hash_dict[uuid] = {
                    'hostname': record.get('hostname', ''),
                    'model': f'{manufacturer} {model}',
                    'role': record.get('role', ''),
                    'mzone': record.get('cluster', 'NA'),
                    'cluster': record.get('cluster', 'NA'),
                    'application': record.get('application', 'NA'),
                    'datacenter': record.get('datacenter', 'NA'),
                    'mac': ni['mac'],
                    'environment': record.get('environment', ''),
                    'asset_type': record.get('compliance', {}).get('itcs104_sub_group', ''),
                    'sos_status': sos_status,
                    'server_type': server_type,
                    'os': f'{os_title} {os_version} {os_architecture}'
                }

        return sos_hash_dict

    def __sc_results(self):
        self.__logger.info('Reading security center results.')
        if self.__with_compression:
            return json.loads(hlpr.decompress_text(self.__sc_evidence.read_bytes()))
        else:
            return json.loads(self.__sc_evidence.read_text())
