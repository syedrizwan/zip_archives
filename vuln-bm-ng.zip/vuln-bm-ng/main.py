# -*- coding:utf-8; mode:python -*-
import argparse
import datetime
import logging
import os
import time

import urllib3
from decouple import config

import vuln_benchmark_ticketing.utils.helper as hlpr
from vuln_benchmark_ticketing.inventory_fetcher import InventoryFetcher
from vuln_benchmark_ticketing.jira_notifier import JiraNotifier
from vuln_benchmark_ticketing.reports_generator import ReportsGenerator
from vuln_benchmark_ticketing.sc_fetcher import SCFetcher
from vuln_benchmark_ticketing.utils.constants import LOGGING_DATE_FORMAT, LOGGING_MSG_FORMAT, TZ
from vuln_benchmark_ticketing.utils.slack_notifier import SlackNotifier

if __name__ == '__main__':
    urllib3.disable_warnings()

    n_start = time.time()

    parser = argparse.ArgumentParser(description='Vulnerability and Benchmark ticketing process for NextGen.')
    parser.add_argument('-sc', '--sec_center', action='store_true', help='Fetch vuln and benchmark results from security center.')
    parser.add_argument('-sos', '--sos_db', action='store_true', help='Fetch GENTOR inventory from SOS DB.')
    parser.add_argument('-r', '--reports', action='store_true', help='Create reports from SC and SOS evidence.')
    parser.add_argument('-j', '--jira', action='store_true', help='Execute jira notifier.')
    parser.add_argument('-c', '--compress', action='store_true', help='Compress generated evidence.')
    parser.add_argument("-dc", '--datacenter', choices=["SAO", "SYD", "PAR", "TOK", "OSA", "FRA", "LON", "WDC", "DAL", "TOR"], help='Get results based on Datacenter', nargs="+")

    args = parser.parse_args()

    e_sc = args.sec_center
    e_sos = args.sos_db
    e_jira = args.jira
    e_reports = args.reports
    e_compress = args.compress
    e_datacenter = args.datacenter

    logging.Formatter.converter = lambda *arg: datetime.datetime.now(TZ).timetuple()
    logging.basicConfig(level=logging.INFO, format=LOGGING_MSG_FORMAT, datefmt=LOGGING_DATE_FORMAT)
    logger = logging.getLogger('main')
    slack_notifier = SlackNotifier('NG Vulnerability & Benchmark Reporter')

    logger.info('Getting ticket assignment config.')
    assignment_config_file_name = hlpr.get_assignment_config(config('GH_TOKEN'))

    if e_sos:
        _tmp = InventoryFetcher(logger=logger, slack_notifier=slack_notifier)
        _tmp.fetch()

    if e_sc:
        _tmp = SCFetcher(logger=logger, slack_notifier=slack_notifier, with_compression=e_compress, with_dc=e_datacenter)
        _tmp.fetch()

    if e_reports:
        _tmp = ReportsGenerator(logger=logger, slack_notifier=slack_notifier, with_compression=e_compress, with_dc=e_datacenter, assignment_config_file_name=assignment_config_file_name)
        _tmp.generate()
        pass

    if e_jira:
        _tmp = JiraNotifier(logger=logger, slack_notifier=slack_notifier, with_compression=e_compress, with_dc=e_datacenter, assignment_config_file_name=assignment_config_file_name)
        _tmp.notify()
        pass
    os.remove(assignment_config_file_name)

    n_end = time.time()

    logger.info(f'Total script execution time: {datetime.timedelta(seconds=n_end - n_start)}')
